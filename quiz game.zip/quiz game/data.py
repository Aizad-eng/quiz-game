science = [
    {"text": "A slug's blood is green.", "answer": "True"},
    {"text": "The loudest animal is the African Elephant.", "answer": "False"},
    {"text": "Approximately one quarter of human bones are in the feet.", "answer": "True"},
    {"text": "The total surface area of a human lungs is the size of a football pitch.", "answer": "True"},
    {
        "text": "In West Virginia, USA, if you accidentally hit an animal with your car, you are free to take it home to eat.",
        "answer": "True"},
    {"text": "In London, UK, if you happen to die in the House of Parliament, you are entitled to a state funeral.",
     "answer": "False"},
    {"text": "It is illegal to pee in the Ocean in Portugal.", "answer": "True"},
    {"text": "You can lead a cow down stairs but not up stairs.", "answer": "False"},
    {"text": "Google was originally called 'Backrub'.", "answer": "True"},
    {"text": "Buzz Aldrin's mother's maiden name was 'Moon'.", "answer": "True"},
    {"text": "No piece of square dry paper can be folded in half more than 7 times.", "answer": "False"},
    {"text": "A few ounces of chocolate can to kill a small dog.", "answer": "True"}
]

general_knowledge = [

            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "Video streaming website YouTube was purchased in it&#039;s entirety by Facebook for US$1.65 billion in stock.",
                "answer": "False",
                "incorrect_answers": [
                    "True"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "Gumbo is a stew that originated in Louisiana.",
                "answer": "True",
                "incorrect_answers": [
                    "False"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "It is automatically considered entrapment in the United States if the police sell you illegal substances without revealing themselves.",
                "answer": "False",
                "incorrect_answers": [
                    "True"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "Ananas; is mostly used as the word for Pineapple in other languages.",
                "answer": "True",
                "incorrect_answers": [
                    "False"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "The Sun rises from the North.",
                "answer": "False",
                "incorrect_answers": [
                    "True"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "In 2010, Twitter and the United States Library of Congress partnered together to archive every tweet by American citizens.",
                "answer": "True",
                "incorrect_answers": [
                    "False"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "Adolf Hitler was born in Australia. ",
                "answer": "False",
                "incorrect_answers": [
                    "True"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "&quot;27 Club&quot; is a term used to refer to a list of famous actors, musicians, and artists who died at the age of 27.",
                "answer": "True",
                "incorrect_answers": [
                    "False"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "Vietnam&#039;s national flag is a red star in front of a yellow background.",
                "answer": "False",
                "incorrect_answers": [
                    "True"
                ]
            },
            {
                "category": "General Knowledge",
                "type": "boolean",
                "difficulty": "easy",
                "text": "Slovakia is a member of European Union-",
                "answer": "True",
                "incorrect_answers": [
                    "False"
                ]
            }
        ]
